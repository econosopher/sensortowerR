library(testthat)
library(sensortowerR)

test_check("sensortowerR") 